## Python版本
```
python 3.11.10
```

## 安裝套件
```
pip install Flask==3.0.3 
pip install mysqlclient==2.2.5
```