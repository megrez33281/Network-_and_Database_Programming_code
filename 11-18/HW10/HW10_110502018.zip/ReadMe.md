## Version
'''
python 3.9.13
'''

## Package
'''
pip install pandas==2.2.3
pip install pathlib==1.0.1
pip install scikit-learn==1.5.2
pip install matplotlib==3.9.2
'''